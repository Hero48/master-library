
git pull origin master
python app.py